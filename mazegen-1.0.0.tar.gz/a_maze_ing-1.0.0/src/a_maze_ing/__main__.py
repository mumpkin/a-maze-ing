"""A-MAZE-ING.

 _____     _____ _____ _____ _____     _____ _____ _____
|  _  |___|     |  _  |__   |   __|___|     |   | |   __|
|     |___| | | |     |   __|   __|___|-   -| | | |  |  |
|__|__|   |_|_|_|__|__|_____|_____|   |_____|_|___|_____|
"""

import sys

from . import App

if __name__ == "__main__":
    """Run the app."""
    try:
        app = App()
        app.run()
    except Exception as e:
        print("[RUNTIME ERROR]:", e, file=sys.stderr)
        exit(1)
